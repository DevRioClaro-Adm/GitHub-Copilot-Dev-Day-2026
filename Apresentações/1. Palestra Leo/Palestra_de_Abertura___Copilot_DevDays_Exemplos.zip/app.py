# função que calcula o fatorial de um número
def fatorial(n):    
    if not isinstance(n, int) or n < 0:
        raise ValueError("Fatorial não é definido para números negativos ou não inteiros")
    if n == 0 or n == 1:
        return 1
    else:
        return n * fatorial(n - 1)
    
# main do programa
if __name__ == "__main__":
    numero = int(input("Digite um número para calcular o fatorial: "))
    resultado = fatorial(numero)
    print(f"O fatorial de {numero} é: {resultado}")