import pytest
from app import fatorial

def test_fatorial_zero():
    """Test fatorial for n=0, should return 1."""
    assert fatorial(0) == 1

def test_fatorial_one():
    """Test fatorial for n=1, should return 1."""
    assert fatorial(1) == 1

def test_fatorial_two():
    """Test fatorial for n=2, should return 2."""
    assert fatorial(2) == 2

def test_fatorial_three():
    """Test fatorial for n=3, should return 6."""
    assert fatorial(3) == 6

def test_fatorial_four():
    """Test fatorial for n=4, should return 24."""
    assert fatorial(4) == 24

def test_fatorial_five():
    """Test fatorial for n=5, should return 120."""
    assert fatorial(5) == 120

def test_fatorial_negative():
    """Test fatorial for negative n, should raise ValueError."""
    with pytest.raises(ValueError, match="Fatorial não é definido para números negativos"):
        fatorial(-1)