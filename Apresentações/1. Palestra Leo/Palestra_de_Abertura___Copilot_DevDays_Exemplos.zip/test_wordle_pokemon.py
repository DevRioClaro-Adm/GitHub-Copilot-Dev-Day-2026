import pytest
import wordle_pokemon as wp
from wordle_pokemon import (
    comparar_letras,
    mostrar_acertos,
    validar_entrada,
    mostrar_dicas,
    processar_dica,
    processar_palpite,
    escolher_pokemon,
)


def test_comparar_letras_retorna_cores_corretas():
    resultado = comparar_letras("pikachu", "pixxchz")
    assert resultado == ["verde", "verde", "cinza", "cinza", "verde", "verde", "cinza"]


def test_comparar_letras_com_tamanho_invalido_levanta_erro():
    with pytest.raises(ValueError, match="Digite uma palavra com 7 letras."):
        comparar_letras("pikachu", "pika")


def test_comparar_letras_com_tamanho_diferente_levanta_erro():
    with pytest.raises(ValueError, match="Digite uma palavra com 7 letras."):
        comparar_letras("pikachu", "pikachu1")


def test_mostrar_acertos_exibe_apenas_letras_verdes():
    resultado = ["verde", "verde", "cinza", "cinza", "amarelo", "verde", "cinza"]
    acertos = mostrar_acertos("pikachu", "pixxchz", resultado)
    assert acertos == "p i _ _ _ h _"


def test_validar_entrada_retorna_mensagem_para_entrada_vazia():
    assert validar_entrada("", "charizard") == "⚠️ Digite algo válido!"


def test_validar_entrada_retorna_mensagem_para_tamanho_invalido():
    assert validar_entrada("pika", "pikachu") == "Entrada inválida: use 7 letras."


def test_validar_entrada_retorna_none_para_entrada_valida():
    assert validar_entrada("pikachu", "pikachu") is None


def test_mostrar_dicas_retorna_texto_formatado(monkeypatch):
    monkeypatch.setattr(wp.random, "choice", lambda options: options[0])
    assert mostrar_dicas("charizard", 1) == "Este Pokémon é do tipo fogo."
    assert mostrar_dicas("pikachu", 3) == "Ele pode aprender trovão, cabeçada."


def test_mostrar_dicas_sem_mais_dicas():
    assert mostrar_dicas("pikachu", 6) == "Sem mais dicas!"


def test_processar_dica_incrementa_e_imprime_dica(capsys):
    dicas_usadas = processar_dica("pikachu", 0)
    captured = capsys.readouterr()
    assert dicas_usadas == 1
    assert "Dica 1:" in captured.out


def test_processar_dica_nao_excede_limite(capsys):
    dicas_usadas = processar_dica("pikachu", 5)
    captured = capsys.readouterr()
    assert dicas_usadas == 5
    assert "Você já usou todas as dicas!" in captured.out


def test_processar_palpite_acerto_retorna_true():
    acertou, tentativas = processar_palpite("pikachu", "pikachu", 6)
    assert acertou is True
    assert tentativas == 6


def test_processar_palpite_errado_reduz_tentativas(capsys):
    acertou, tentativas = processar_palpite("raichuu", "pikachu", 6)
    captured = capsys.readouterr()
    assert acertou is False
    assert tentativas == 5
    assert "Errado" in captured.out
    assert "Acertos na posição correta:" in captured.out


def test_escolher_pokemon_usa_random_choice(monkeypatch):
    monkeypatch.setattr(wp.random, "choice", lambda options: "blastoise")
    assert escolher_pokemon() == "blastoise"