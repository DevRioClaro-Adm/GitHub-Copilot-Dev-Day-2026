import os
import random

# Inicializa o gerador aleatório com entropia forte do sistema
random.seed(os.urandom(32))

# Lista de Pokémon com informações
POKEMONS = {
    "pikachu": {"tipo": "elétrico", "habilidade": "estática", "ataques": ["trovão", "cabeçada"], "cor": "amarelo", "geracao": 1},
    "charizard": {"tipo": "fogo", "habilidade": "chama-body", "ataques": ["lança-chamas", "voo"], "cor": "laranja", "geracao": 1},
    "blastoise": {"tipo": "água", "habilidade": "torrente", "ataques": ["hidro-bomba", "pulso-aquático"], "cor": "azul", "geracao": 1},
    "dragonite": {"tipo": "dragão", "habilidade": "multiescar", "ataques": ["dança-dragão", "hiperraio"], "cor": "marrom", "geracao": 1},
    "gyarados": {"tipo": "água", "habilidade": "intimidação", "ataques": ["terremoto", "hidro-vórtice"], "cor": "azul", "geracao": 1},
    "alakazam": {"tipo": "psíquico", "habilidade": "mágica-espelhada", "ataques": ["psíquico", "foco-total"], "cor": "roxo", "geracao": 1},
    "venusaur": {"tipo": "grama", "habilidade": "suco-abafante", "ataques": ["semente-rajada", "pó-dorminhoco"], "cor": "verde", "geracao": 1},
    "arcanine": {"tipo": "fogo", "habilidade": "potência-bruta", "ataques": ["lança-chamas", "ataque-rápido"], "cor": "vermelho", "geracao": 1},
    "lapras": {"tipo": "água", "habilidade": "concha-armadura", "ataques": ["surf", "aurora"], "cor": "branco", "geracao": 1},
    "gengar": {"tipo": "fantasma", "habilidade": "levitar", "ataques": ["bola-sombra", "focoenergia"], "cor": "roxo", "geracao": 1},
    "machamp": {"tipo": "lutador", "habilidade": "potência-bruta", "ataques": ["golpe-dinâmico", "soco-de-poder"], "cor": "marrom", "geracao": 1},
    "golem": {"tipo": "rocha", "habilidade": "corpoarmadura", "ataques": ["terremoto", "pedra-rochosa"], "cor": "marrom", "geracao": 1},
    "articuno": {"tipo": "gelo", "habilidade": "pressão", "ataques": ["nevasca", "ventania"], "cor": "branco", "geracao": 1},
    "zapdos": {"tipo": "elétrico", "habilidade": "pressão", "ataques": ["trovão", "bicaço"], "cor": "amarelo", "geracao": 1},
    "moltres": {"tipo": "fogo", "habilidade": "pressão", "ataques": ["lança-chamas", "voo"], "cor": "vermelho", "geracao": 1},
    "mewtwo": {"tipo": "psíquico", "habilidade": "pressão", "ataques": ["psíquico", "bola-sombra"], "cor": "roxo", "geracao": 1},
    "mew": {"tipo": "psíquico", "habilidade": "sincronismo", "ataques": ["psíquico", "teletransporte"], "cor": "rosa", "geracao": 1}
}

HINT_TEMPLATES = {
    "tipo": [
        "Este Pokémon é do tipo {tipo}.",
        "O tipo principal dele é {tipo}.",
        "Seu elemento é {tipo}."
    ],
    "habilidade": [
        "A habilidade desse Pokémon é {habilidade}.",
        "Ele possui a habilidade {habilidade}.",
        "Sua habilidade especial é {habilidade}."
    ],
    "ataques": [
        "Ele pode aprender {ataques}.",
        "Alguns de seus ataques são {ataques}.",
        "Entre os movimentos dele estão {ataques}."
    ],
    "cor": [
        "A cor dominante dele é {cor}.",
        "Sua aparência tem tom {cor}.",
        "Ele é conhecido por ser {cor}."
    ],
    "geracao": [
        "Ele foi introduzido na geração {geracao}.",
        "Esse Pokémon é da geração {geracao}.",
        "Ele aparece pela primeira vez na geração {geracao}."
    ]
}

def escolher_pokemon():
    """Escolhe um Pokémon aleatório."""
    return random.choice(list(POKEMONS.keys()))

def mostrar_dicas(pokemon, dica_num):
    """Mostra dicas sobre o Pokémon usando frases variadas."""
    info = POKEMONS[pokemon]
    atributos = ["tipo", "habilidade", "ataques", "cor", "geracao"]
    if dica_num <= len(atributos):
        atributo = atributos[dica_num - 1]
        template = random.choice(HINT_TEMPLATES[atributo])
        valor = info[atributo]
        if atributo == "ataques":
            valor = ", ".join(valor)
        return template.format(**{atributo: valor})
    return "Sem mais dicas!"

def comparar_letras(palavra_correta, palavra):
    if len(palavra) != len(palavra_correta):
        raise ValueError(
            f"Digite uma palavra com {len(palavra_correta)} letras."
        )

    resultado = []
    for i, letra in enumerate(palavra):
        if letra == palavra_correta[i]:
            resultado.append("\033[92mverde\033[0m")  # Verde
        elif letra in palavra_correta:
            resultado.append("\033[93mamarelo\033[0m")  # Amarelo
        else:
            resultado.append("\033[91mvermelho\033[0m")  # Vermelho
    return resultado


def mostrar_acertos(palavra_correta, palpite, resultado):
    """Mostra apenas as letras verdes na posição correta."""
    partes = []
    for i, cor in enumerate(resultado):
        partes.append(palpite[i] if cor == "verde" else "_")
    return " ".join(partes)


def solicitar_palpite(pokemon_correto):
    placeholder = "_" * len(pokemon_correto)
    return input(f"Digite seu palpite ({placeholder}): ").lower().strip()


def processar_dica(pokemon_correto, dicas_usadas):
    if dicas_usadas < 5:
        dicas_usadas += 1
        print(f"💡 Dica {dicas_usadas}: {mostrar_dicas(pokemon_correto, dicas_usadas)}")
    else:
        print("❌ Você já usou todas as dicas!")
    return dicas_usadas


def inicializar_placar():
    return {"vitorias": 0, "derrotas": 0, "max_pontuacao": 0}


def calcular_pontuacao(acertou, tentativas_restantes):
    return tentativas_restantes if acertou else 0


def atualizar_placar(placar, acertou, tentativas_restantes):
    if acertou:
        placar["vitorias"] += 1
    else:
        placar["derrotas"] += 1

    pontuacao = calcular_pontuacao(acertou, tentativas_restantes)
    placar["max_pontuacao"] = max(placar["max_pontuacao"], pontuacao)
    return placar


def formatar_placar(placar):
    return (
        f"Vitórias: {placar['vitorias']}\n"
        f"Derrotas: {placar['derrotas']}\n"
        f"Maior pontuação: {placar['max_pontuacao']}"
    )


def validar_entrada(entrada, pokemon_correto):
    if len(entrada) == 0:
        return "⚠️ Digite algo válido!"
    if len(entrada) != len(pokemon_correto):
        return f"Entrada inválida: use {len(pokemon_correto)} letras."
    return None


def processar_palpite(entrada, pokemon_correto, tentativas):
    if entrada == pokemon_correto:
        print(f"\n🎉 PARABÉNS! Você acertou: {pokemon_correto.upper()}")
        return True, tentativas

    tentativas -= 1
    print(f"\n❌ Errado! Veja as letras:")
    letras_resultado = comparar_letras(pokemon_correto, entrada)
    print(" ".join(letras_resultado))
    print("Acertos na posição correta:", mostrar_acertos(pokemon_correto, entrada, letras_resultado))

    if tentativas == 0:
        print(f"\n💔 Game Over! Era: {pokemon_correto.upper()}")
    return False, tentativas


def jogar():
    """Função principal do jogo."""
    placar = inicializar_placar()

    print("🎮 WORDLE POKÉMON 🎮")
    print("Você tem 6 tentativas para adivinhar o Pokémon!")
    print("Você pode pedir até 5 dicas digitando 'dica'.\n")
    print("Legenda: verde = letra certa na posição certa; amarelo = letra existe no nome, mas em outra posição; cinza = letra não está no nome.\n")

    while True:
        pokemon_correto = escolher_pokemon()
        tentativas = 6
        dicas_usadas = 0
        acertou = False

        while tentativas > 0 and not acertou:
            print(f"\n📍 Tentativas restantes: {tentativas}")
            entrada = solicitar_palpite(pokemon_correto)

            if entrada == "dica":
                dicas_usadas = processar_dica(pokemon_correto, dicas_usadas)
                continue

            erro = validar_entrada(entrada, pokemon_correto)
            if erro:
                print(erro)
                continue

            acertou, tentativas = processar_palpite(entrada, pokemon_correto, tentativas)

        placar = atualizar_placar(placar, acertou, tentativas)
        print("\n📊 Placar atual:")
        print(formatar_placar(placar))

        jogar_novamente = input("\nDeseja jogar outra partida? (s/n): ").strip().lower()
        if jogar_novamente != "s":
            break

    print("\n" + "="*40)
    print("Sessão finalizada.")
    print(formatar_placar(placar))
    print("✨ Obrigado por jogar!")

if __name__ == "__main__":
    jogar()
